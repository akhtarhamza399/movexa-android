MOVEXA Android APK project
==========================
This is a native Android Studio project wrapping the MOVEXA app in an Android WebView.

To build APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Let Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output is usually app/build/outputs/apk/debug/app-debug.apk.

This environment cannot run Android Studio/Gradle or sign and test an APK, so this package is source code, NOT an APK file.
The current app is still a local demo: bookings are stored only on this device. It has no secure backend, shared customer/employee accounts, real OTP, payment processing or live hosting.
